import React from 'react';
import { StyleSheet, Text, View, FlatList, Image } from 'react-native';
import { MotiView } from 'moti';
import { bagsList } from './Constants';
import { ColorsApp } from '../../../utilities/colors';
import { WIDTH_SCREEN, spaceLeftRightList } from '../../../constants/constants';
import SearchBar from '../../components/searchBar';
import Segment from '../../../navigation/segment';
import StylesG from '../../../utilities/stylesG';
import { Fonts } from '../../../utilities/fonts';
import Images from '../../../assets/images';

const itemMargin = spaceLeftRightList;

const Search = () => {
  const renderItem = ({ item, index }) => {
    return (
      <MotiView
        style={styles.listContainer}
        from={{ opacity: 0, translateY: 50 }}
        animate={{ opacity: 1, translateY: 0 }}
        transition={{ delay: 1000 + index * 200 }}>
        <View style={styles.imageContainer}>
          <Image source={{ uri: item.img }} style={styles.image} />
          <View
            style={styles.playContainer}>
            <Images.play height={14} width={14} />
            <Text style={styles.socialCount}>45.5k</Text>
          </View>
        </View>
        <View style={styles.textContainer}>
          <View style={styles.profileContainer}>
            <Image source={{ uri: item.profile }} style={styles.profile} />
          </View>
          <Text
            numberOfLines={1}
            style={[styles.text, { color: ColorsApp.black }]}>
            {item.title}
          </Text>
        </View>
      </MotiView>
    );
  };

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: ColorsApp.white,
      }}>
      <View style={{ paddingHorizontal: 18, paddingVertical: 9 }}>
        <SearchBar onSearchTyping={(searchText: string) => { }} />
      </View>

      <View style={{ height: 56 }}>
        <Segment />
      </View>

      <FlatList
        data={bagsList}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        numColumns={2}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.flatListContent}
        columnWrapperStyle={styles.columnWrapper}
        ListFooterComponent={() => {
          return <View style={StylesG.footer} />;
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  flatListContent: {
    paddingHorizontal: itemMargin,
    paddingTop: 21,
    gap: itemMargin,
  },

  columnWrapper: {
    justifyContent: 'flex-start',
    gap: itemMargin,
  },
  listContainer: {
    width: (WIDTH_SCREEN - itemMargin * 3) / 2,
  },
  imageContainer: {
    height: 218,
    backgroundColor: ColorsApp.white,
    borderRadius: 14,
  },
  count: {
    ...Fonts.poppinsMedium10,
  },
  profileContainer: {
    width: 30,
  },
  profile: {
    width: '100%',
    height: 30,
    borderRadius: 15,
  },
  image: {
    width: '100%',
    height: 218,
    // aspectRatio: 1,
    borderRadius: 14,
  },
  textContainer: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  text: {
    ...Fonts.poppinsMedium13,
    paddingHorizontal: 7,
    flex: 1,
  },
  playContainer: {
    position: 'absolute',
    bottom: 0,
    padding: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  socialCount: {
    ...Fonts.poppinsMedium17,
    color: ColorsApp.white
  },
});

export default Search;
